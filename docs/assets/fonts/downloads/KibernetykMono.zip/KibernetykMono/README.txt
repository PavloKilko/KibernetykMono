Kibernetyk Mono v1.0.2
Designed by Pavlo Kilko.

Install the TTF files using your operating system's font manager.
Select Kibernetyk Mono in your editor.

Source: https://github.com/PavloKilko/KibernetykMono
Licensed under the SIL Open Font License 1.1. See OFL.txt.
